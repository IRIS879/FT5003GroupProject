# Demo walkthrough (8–15 min recorded video)

Scene-by-scene script for the Forum Builder Fund DAO demo. Target length 10 min.
Every section ends with a ✅ checkpoint — if the checkpoint doesn't show up on
screen, stop and debug before continuing.

> **Two modes.** The `Frontend mode` sections below use the web UI
> (`./run-frontend.sh` → <http://localhost:8080>) and are the recommended
> flow for the recording. The `CLI mode` sections stay as the fallback if you
> only want to show terminals.

## Prep (before recording)

1. Clean state:
   ```bash
   rm -rf 5003final/cache 5003final/artifacts
   pkill -f "hardhat node" || true
   ```
2. Open three panes:
   - **Pane A:** `5003final/` — will run `npx hardhat node`
   - **Pane B:** `5003final/` — will run deploy + Spring Boot runner
   - **Pane C:** `5003final/` — will run `./mvnw test`
3. Zoom terminal font to 16pt+ so it's legible in the recording.
4. Have [README.md](README.md) open in a side editor for the rules table.

## Scene 1 — Intro & architecture (≈1.5 min)

- Show the README rules table. Call out the three interesting numbers:
  **quorum = 5, threshold = 3, budget = 5000 USDC**.
- Open [ForumTreasury.sol](contracts/ForumTreasury.sol), highlight
  `executeTreasury(recipients, amounts)` and the `onlyAdmin` modifier — this
  is the only on-chain write path.
- Open [GovernanceService.java](src/main/java/com/dao/service/GovernanceService.java),
  scroll to `submitProposal`, `castApprovalVote`, `tallyRound`. Narrate:
  *"off-chain engine decides who wins; the contract just pays."*

## Scene 2 — Boot the chain & deploy (≈1.5 min)

Pane A:
```bash
npx hardhat node
```
✅ Accounts list appears, RPC on `127.0.0.1:8545`.

Pane B:
```bash
npm run -s deploy:raw
```
✅ `SUCCESS: ForumTreasury deployed to: 0x…` and `Seeded treasury with 0.01 ETH`.

Copy the contract address, export it:
```bash
export DAO_CONTRACT_ADDRESS=0x...
```

## Scene 3 — Happy path end-to-end (≈2.5 min)

Pane B:
```bash
./mvnw -q spring-boot:run
```

Narrate as the output streams:
1. `[1] Submit Proposals` — three grant requests are created off-chain.
2. `[2] Cast Approval Votes` — 5 whitelisted members approve.
3. `[3] Tally Round` — show quorum reached, eligible list, winner list,
   remaining budget.
4. `[4] Execute On-Chain Treasury Payouts` — treasury balance before/after
   and the `executeTreasury` tx hash.

✅ Post-execution treasury balance is lower than pre-execution by the payout amount.

Switch to Pane A briefly: point at the Hardhat node log showing the matching
`eth_sendRawTransaction` lines — *"here's the actual on-chain call."*

## Scene 4 — Failure scenarios via unit tests (≈3 min)

This is the most important scene. Pane C:
```bash
./mvnw -q test -Dtest=GovernanceRulesTest
```

✅ All six tests pass. Walk through each one in the source file while the
terminal output is still on screen:

| Test                                                   | What the demo proves                               |
|--------------------------------------------------------|----------------------------------------------------|
| `submit_nonWhitelistedSubmitter_isRejected`            | Submitter whitelist gate                           |
| `vote_nonWhitelistedVoter_isRejected`                  | Voter whitelist gate                               |
| `vote_selfVote_isRejected`                             | Submitter can't vote for themselves                |
| `vote_duplicateApproval_isRejected`                    | One approval per (voter, proposal)                 |
| `tally_quorumNotReached_producesNoWinners_evenIfThresholdMet` | Quorum strictly gates payouts             |
| `tally_budgetInsufficient_skipsProposalThatDoesNotFit` | Budget cap skips, doesn't partial-fund             |

For the last two, open the test in the editor and narrate the setup — viewers
need to see the exact numbers (3 voters < 5 quorum; 4000 + 2000 > 5000 budget,
but 4000 + 800 fits).

## Scene 5 — Happy path + ranking test (≈1 min)

Pane C:
```bash
./mvnw -q test -Dtest=GovernanceServiceTest#tallyRound_sortAndBudgetCutoff
```

✅ Green. Narrate the ranking: p1(4 approvals) > p2(3, earlier) > p3(3, later),
budget funds p1 then p3, skips p2.

## Scene 6 — Wrap (≈0.5 min)

- Recap the three rules that made the demo interesting (quorum, threshold, budget skip).
- Show the GitHub repo URL / README once more.
- End recording.

## Frontend mode — recommended recording flow (≈10 min total)

Prep:
```bash
./run-frontend.sh     # starts Hardhat + deploys + launches Spring Boot
```
Open <http://localhost:8080> in a maximized browser window. Keep the terminal
visible in a small second window so viewers see Hardhat logs scroll during
on-chain calls.

**F-Scene 1 · Intro (1 min)**
- Read the header rules line: *quorum 5 · threshold 3 · budget 5000 USDC*.
- Hover the Members panel; point out 6 whitelisted + 1 outsider (Mallory).
- ✅ Members panel shows 7 rows.

**F-Scene 2 · Failure: non-whitelisted submit (1 min)**
- Click Mallory to select her as acting member.
- Submit any proposal (title `should fail`, any recipient, 1000).
- ✅ Red toast: *Submitter is not whitelisted: 0x1111…*

**F-Scene 3 · Happy path setup (2 min)**
- Click Proposer. Submit 3 proposals matching the budget test:
  - `Moderation tools` → `0x976e…0aa9` · 3000
  - `Education series` → `0x14dc…9955` · 2500
  - `Security review`  → `0x2361…1e8f` · 2000
- ✅ Three cards appear, all "below threshold".

**F-Scene 4 · Failure: self-vote (0.5 min)**
- With Proposer still selected, click Approve on any of his proposals.
- ✅ Red toast: *Self-vote not allowed*.

**F-Scene 5 · Collect approvals + show quorum gate (2 min)**
- Switch to Alice → approve P1, P2.
- Switch to Bob   → approve P1, P2.
- Switch to Carol → approve P1, P3.
- Pause. Right panel: *Unique voters 3/5* in red, quorum NOT reached — even
  though P1 and P2 each have enough approvals, 0 winners.
- Switch to Dave  → approve P1, P3.
- Switch to Eve   → approve P2, P3.
- ✅ Quorum turns green (5/5). P1 and P3 become WINNER cards; P2 stays
  eligible (yellow) because `3000 + 2000 = 5000` already fills the budget
  and `2500` doesn't fit the 2000 remaining → budget skip.

**F-Scene 6 · Failure: duplicate approval (0.5 min)**
- With Eve still selected, click Approve on P3 again.
- ✅ Red toast: *Duplicate approval vote*.

**F-Scene 7 · On-chain execution (1.5 min)**
- Click Execute on-chain payout.
- ✅ Green toast with tx hash. Treasury balance (Wei) drops visibly.
- Alt-tab to the Hardhat log window, point at the matching
  `eth_sendRawTransaction` line — this is the real chain call.

**F-Scene 8 · Tests as proof (1 min)**
- Shrink browser, open a terminal, run:
  ```
  ./mvnw -q test -Dtest=GovernanceRulesTest
  ```
- ✅ 6 green tests. Flash each test name while the output is on screen:
  whitelist × 2, self-vote, duplicate, quorum, budget skip.

**F-Scene 9 · Wrap (0.5 min)**
- Recap: off-chain engine enforces rules, on-chain contract just pays.
- Show GitHub URL. End recording.

## CLI mode — fallback script

(Keep the earlier Scenes 1–6 in this file as the CLI fallback if the frontend
fails on recording day.)

## Common gotchas during recording

- **"Treasury Error: Insufficient balance"** on `executeTreasury` — the seed
  step didn't run. Re-run `npm run -s deploy:raw` with `DAO_SEED_TREASURY=true`.
- **`Cannot reach RPC endpoint`** — you forgot Pane A, or it crashed. Check
  `hardhat-node.log`.
- **`Submitter is not whitelisted`** when running the Spring Boot flow — means
  you edited `DaoApplication.java` and removed `proposer` from the whitelist list.
- **Stale contract address** — every `npm run deploy:raw` produces a new
  address; re-export `DAO_CONTRACT_ADDRESS` before re-running the Java flow.
